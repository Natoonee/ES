# 实验报告模板

学院：省级示范性软件学院
课程：高级数据库技术与应用
题目：《 实验四：Logstash操作》
姓名：杨尧炜
学号：2200770008
班级：软工2201
日期：2024-10-28
实验环境： Elasticsearch8.12.2 apifox Logstash

---
## 一.实验目的 
验证Logstash从文件/数据库采集数据并同步到Elasticsearch的可行性和效率。

通过以下步骤，可以有效地处理Tomcat日志，并将其导入到Elasticsearch中进行深入分析。同时，也可以实现MySQL数据库到Elasticsearch的数据同步，确保数据的实时性和一致性。

## 二.实验内容 

### tomcat日志处理
数据来源：本地的tomcat的logs中的日志或使用下面的文件

要求：
1. 将tomcat的logs中的localhost_access_log访问日志导入到本地的elasticsearch中。

2. 数据导入到一个名为tomcat_logs的索引。

3. 在elasticsearch中做5个日志相关的分析，题目自拟。

   logstash测试
   ![QQ20241028-170617](pot/QQ20241028-170617.png)

   logstash配置文件
```
   input {  
    file {  
    path => "E:\xiazail\tomcat_logs\tomcat_logs\localhost_access_log.*.txt"
    start_position => "beginning"  
    }  
}  

filter {  
  grok {  
    match => { "message" => "%{COMBINEDAPACHELOG}" }  
  }  
  date {  
    match => [ "timestamp" , "dd/MMM/yyyy:HH:mm:ss Z" ]  
    target => "@timestamp"  
  }  
}  

output {  
  elasticsearch {  
    hosts => ["localhost:9200"]  
    index => "tomcat_logs"  
  }  
}
```
1. 每日请求量分析
题目：分析Tomcat服务器每日接收的请求数量。

分析方法：

使用Elasticsearch的聚合查询（Aggregations）功能。
对@timestamp字段进行日期直方图（Date Histogram）聚合，设置为按天（day）分组。
统计每个分组中的文档数量（即请求数量）。
Elasticsearch查询示例：
```

GET /tomcat_logs-*/_search  
{  
  "size": 0,  
  "aggs": {  
    "requests_per_day": {  
      "date_histogram": {  
        "field": "@timestamp",  
        "calendar_interval": "day"  
      }  
    }  
  }  
}
```
1![QQ20241104-164113](pot/QQ20241104-164113.png)

2. 响应状态码分布分析
题目：分析Tomcat服务器返回的不同HTTP响应状态码的分布情况。

分析方法：

使用术语聚合（Terms Aggregation）对response_code字段进行分组。
统计每个响应状态码出现的次数。
Elasticsearch查询示例：
```

GET /tomcat_logs-*/_search  
{  
  "size": 0,  
  "aggs": {  
    "response_codes": {  
      "terms": {  
        "field": "response_code.keyword"  
      }  
    }  
  }  
}
```
1![QQ20241104-164447](pot/QQ20241104-164447.png)

3. 请求方法分析
题目：分析Tomcat服务器接收到的不同HTTP请求方法的比例。

分析方法：

使用术语聚合对method字段进行分组。
统计每种请求方法（如GET、POST等）出现的次数。
Elasticsearch查询示例：
```

GET /tomcat_logs-*/_search  
{  
  "size": 0,  
  "aggs": {  
    "request_methods": {  
      "terms": {  
        "field": "method.keyword"  
      }  
    }  
  }  
}
```
![QQ20241104-164351](pot/QQ20241104-164351.png)
4. 请求路径分析
题目：分析Tomcat服务器上最常被访问的路径。

分析方法：

使用术语聚合对request字段进行分组（可能需要对URL进行进一步的处理以提取路径）。
统计每个路径被访问的次数。
注意：request字段应包含完整的请求行，可能需要额外的处理来提取路径部分。这里假设request字段已经是路径。

Elasticsearch查询示例：
```

GET /tomcat_logs-*/_search  
{  
  "size": 0,  
  "aggs": {  
    "most_requested_paths": {  
      "terms": {  
        "field": "request.keyword"  
      }  
    }  
  }  
}
```
1![QQ20241104-164536](pot/QQ20241104-164536.png)

5. 客户端IP地址分析
题目：分析访问Tomcat服务器的客户端IP地址分布。

分析方法：

使用术语聚合对client_ip字段进行分组。
统计每个IP地址访问的次数。
Elasticsearch查询示例：
```

GET /tomcat_logs-*/_search  
{  
  "size": 0,  
  "aggs": {  
    "client_ips": {  
      "terms": {  
        "field": "client_ip.keyword"  
      }  
    }  
  }  
}
```
1![QQ20241104-164707](pot/QQ20241104-164707.png)

### 数据转换和传输
要求：
1. 将本地的mysql数据库中的一张表导入到本地的elasticsearch中。

2. 数据库表更新后，数据能够自动同步到elasticsearch中。

```
input {
  jdbc {
    jdbc_connection_string =>"jdbc:mysql://localhost:3306/estest"
    jdbc_user => "root"
    jdbc_password => "123456"
    jdbc_driver_class => "com.mysql.cj.jdbc.Driver"
    jdbc_driver_library => "C:\Users\YYW\.m2\repository\mysql\mysql-connector-java\8.0.28\mysql-connector-java-8.0.28.jar"
    jdbc_paging_enabled => "true"
    jdbc_page_size => "50000"  
    schedule => "* * * * *"
    statement => "SELECT * FROM employees"
    use_column_value => true
    tracking_column => "id"
  }
}

filter {

}

output {
  elasticsearch {
    hosts => ["localhost:9200"]
    index => "employees_index"
    document_id => "%{id}"
  }  
}
```
1![QQ20241104-171110](pot/QQ20241104-171110.png)
查询所有记录

```
GET /employees_index/_search  
{  
  "query": {  
    "match_all": {}  
  }  
}
```
![QQ20241104-171507](pot/QQ20241104-171507.png)
查询id为50的员工后删除

```
{  
  "query": {  
    "term": {  
      "id": 50 
    }  
  }  
}
```
![QQ20241104-171638](pot/QQ20241104-171638.png)
一分钟后再次查询
![QQ20241104-171942](pot/QQ20241104-171942.png)
## 三.问题及解决办法
找不到idea中maven使用jdbc的jar包